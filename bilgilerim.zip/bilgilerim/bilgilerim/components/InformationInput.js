import { StyleSheet, Text, View,Modal ,Image,TextInput,Button} from 'react-native'
import React ,{useState} from 'react'

export default function InformationInput({visible , onAddInformation, onCancel}) {
    const [enteredInformationText, setEnteredInformationText] = useState('')
    const addInformationHandler = () => {
        onAddInformation(enteredInformationText)
    }
    const InformationInputHandler = (enteredText) => {
        setEnteredInformationText('');
    }
  return (
<Modal
        animationType="slide" visible={visible}
        >
        <View style={styles.inputContainer}>
            <Image  style={styles.img}source={require('../assets/react_native.png')}/>
            <TextInput style={styles.textInput}
            placeholder='Bizimle Yeni Bir Bilgi Paylaşın :)' value={enteredInformationText} onChangeText={InformationInputHandler}></TextInput>
          <View style={styles.buttonContainer}>
            <View style={styles.button}>
                <Button title='İptal et' color ={'red'} onPress={onCancel} ></Button>
            </View>
            <View style={styles.button}>
                <Button title='Ekle' color ={'blue'} onPress={addInformationHandler}></Button>
            </View>
          </View>
        </View>
      </Modal>
  )
}

const styles = StyleSheet.create({
    inputContainer:{
        flex:1,
        justifyContent:'center',
        alignItems:'center',
    },
    img:{
        width:100,
        height:100,
        alignSelf:'center',
        margin:20,
        borderRadius:20,
    },
    textInput:{
        width:300,
        borderBottomColor:'pink',
        borderBottomWidth:1,
        marginBottom:10,
        padding:10,
        borderRadius:10,
    },
    buttonContainer:{
        flexDirection:'row',
        justifyContent:'space-between',
        width:'60%',
        marginTop:15,
    },
    button:{
        width:'40%',
        marginHorizontal:10,
    }
})